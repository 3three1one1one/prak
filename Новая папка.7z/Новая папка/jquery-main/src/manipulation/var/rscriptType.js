export var rscriptType = /^$|^module$|\/(?:java|ecma)script/i;
