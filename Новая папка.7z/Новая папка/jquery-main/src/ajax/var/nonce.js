export var nonce = { guid: Date.now() };
