export var location = window.location;
