import { Data } from "../Data.js";

export var dataPriv = new Data();
