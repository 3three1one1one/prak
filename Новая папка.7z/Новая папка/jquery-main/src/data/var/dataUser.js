import { Data } from "../Data.js";

export var dataUser = new Data();
