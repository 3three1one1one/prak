import { pseudos } from "./pseudos.js";

export var rpseudo = new RegExp( pseudos );
