import { whitespace } from "../../var/whitespace.js";

export var rdescend = new RegExp( whitespace + "|>" );
