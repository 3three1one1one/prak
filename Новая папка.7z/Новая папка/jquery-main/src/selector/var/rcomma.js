import { whitespace } from "../../var/whitespace.js";

export var rcomma = new RegExp( "^" + whitespace + "*," + whitespace + "*" );
