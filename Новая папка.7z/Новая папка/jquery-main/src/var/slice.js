import { arr } from "./arr.js";

export var slice = arr.slice;
