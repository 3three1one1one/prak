import { arr } from "./arr.js";

export var indexOf = arr.indexOf;
