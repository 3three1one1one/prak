import { arr } from "./arr.js";

export var pop = arr.pop;
