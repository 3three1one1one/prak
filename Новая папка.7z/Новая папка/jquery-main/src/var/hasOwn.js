import { class2type } from "./class2type.js";

export var hasOwn = class2type.hasOwnProperty;
