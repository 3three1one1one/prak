import { arr } from "./arr.js";

export var sort = arr.sort;
