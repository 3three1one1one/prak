import { hasOwn } from "./hasOwn.js";

export var fnToString = hasOwn.toString;
