import { arr } from "./arr.js";

export var push = arr.push;
