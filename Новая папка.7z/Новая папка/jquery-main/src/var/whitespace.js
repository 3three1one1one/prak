// https://www.w3.org/TR/css3-selectors/#whitespace
export var whitespace = "[\\x20\\t\\r\\n\\f]";
