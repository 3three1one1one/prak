import { document } from "./document.js";

export var isIE = document.documentMode;
