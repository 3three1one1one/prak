import { fnToString } from "./fnToString.js";

export var ObjectFunctionString = fnToString.call( Object );
