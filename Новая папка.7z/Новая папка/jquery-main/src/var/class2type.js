// [[Class]] -> type pairs
export var class2type = {};
