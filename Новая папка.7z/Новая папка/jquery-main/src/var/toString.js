import { class2type } from "./class2type.js";

export var toString = class2type.toString;
