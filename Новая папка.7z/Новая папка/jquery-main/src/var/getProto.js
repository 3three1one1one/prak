export var getProto = Object.getPrototypeOf;
