import { arr } from "./arr.js";

export var splice = arr.splice;
