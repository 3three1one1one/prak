import { document } from "./document.js";

export var documentElement = document.documentElement;
