export var document = window.document;
