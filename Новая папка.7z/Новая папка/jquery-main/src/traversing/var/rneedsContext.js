import { jQuery } from "../../core.js";

import "../../selector.js";

export var rneedsContext = jQuery.expr.match.needsContext;
