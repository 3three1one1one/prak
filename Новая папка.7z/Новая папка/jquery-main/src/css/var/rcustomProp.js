export var rcustomProp = /^--/;
