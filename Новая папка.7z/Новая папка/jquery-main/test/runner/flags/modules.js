export const modules = [
	"basic",

	"ajax",
	"animation",
	"attributes",
	"callbacks",
	"core",
	"css",
	"data",
	"deferred",
	"deprecated",
	"dimensions",
	"effects",
	"event",
	"manipulation",
	"offset",
	"queue",
	"selector",
	"serialize",
	"support",
	"traversing",
	"tween"
];
